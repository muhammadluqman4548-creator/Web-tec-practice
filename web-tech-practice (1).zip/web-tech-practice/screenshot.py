from playwright.sync_api import sync_playwright
import os
base=os.path.abspath('.')
pages={'flexbox':'flexbox/index.html','positioning':'positioning/index.html','selectors':'selectors/index.html'}
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1100,'height':800})
    for n,f in pages.items():
        pg.goto('file://'+os.path.join(base,f)); pg.screenshot(path=f'screenshots/{n}.png',full_page=True)
    b.close()
