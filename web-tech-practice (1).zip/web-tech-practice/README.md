# Web Technologies Practice (HTML & CSS)

Practice work for: **Flexbox**, **CSS Positioning**, **CSS Selectors**.

## Structure
- `flexbox/` - container, items, main/cross axis, direction, justify-content, align-items, wrap, gap, grow, shrink
- `positioning/` - static, relative, absolute, fixed, sticky
- `selectors/` - universal, element, class, ID, attribute, descendant, child, adjacent sibling, general sibling, pseudo-class, pseudo-element
- `screenshots/` - output screenshots of each page

## Output Screenshots
### Flexbox
![Flexbox](screenshots/flexbox.png)
### CSS Positioning
![Positioning](screenshots/positioning.png)
### CSS Selectors
![Selectors](screenshots/selectors.png)

## Run
Open `index.html` in any browser.
